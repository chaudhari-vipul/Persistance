package com.Many_To_Many_Hibernate.Controller;

import java.util.*;
import javax.persistence.*;
import com.Many_To_Many_Hibernate.Entity.*;

public class Control 
{
	public static void main(String[] args) 
	{
		Subject subject1=new Subject();
		subject1.setName("Java");
		subject1.setDuration(30);
		
		Subject subject2=new Subject();
		subject2.setName("Python");
		subject2.setDuration(20);
		
		Subject subject3=new Subject();
		subject3.setName(".Net");
		subject3.setDuration(40);
		
		List<Subject> list=new ArrayList<Subject>();
		list.add(subject1);
		list.add(subject2);
		list.add(subject3);
		
		Teacher teacher1=new Teacher();
		teacher1.setName("Mr.Shivaji");
		teacher1.setAge(34);
		teacher1.setAddress("Pune");
		teacher1.setSubject(list);
		
		Teacher teacher2=new Teacher();
		teacher2.setName("Miss.Sapna");
		teacher2.setAge(30);
		teacher2.setAddress("Mumbai");
		teacher2.setSubject(list);
		
		Teacher teacher3=new Teacher();
		teacher3.setName("Mr.Akshay");
		teacher3.setAge(24);
		teacher3.setAddress("Hydrabad");
		teacher3.setSubject(list);
		
		EntityManagerFactory EFM=Persistence.createEntityManagerFactory("Vipul");
		EntityManager EM=EFM.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		EM.persist(subject1);
		EM.persist(subject2);
		EM.persist(subject3);
		EM.persist(teacher1);
		EM.persist(teacher2);
		EM.persist(teacher3);
		ET.commit();
	}
}

