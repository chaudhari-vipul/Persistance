package com.One_To_Many_Mapping.Control;

import java.util.*;
import javax.persistence.*;
import com.One_To_Many_Mapping.entity.*;

public class SaveMobile 
{
	public static void main(String[]args)
	{
		Person person=new Person();
		person.setName("Vipul");
		person.setEmail("VS12345@gmail.com");
		person.setLocation("Banglore");
		
	List<Sim> sims=new ArrayList<Sim>();
	Sim s1=new Sim();
	s1.setProvidername("jio");
	s1.setSimnumber(123323453l);
	
	Sim s2=new Sim();
	s2.setProvidername("VI");
	s2.setSimnumber(6326986l);
	
	sims.add(s1);
	sims.add(s2);
	
	Mobile m1=new Mobile();
	m1.setMobilename("IPhone 14");
	m1.setBrand("Apple");
	m1.setCost(57125);
	m1.setSims(sims);
	person.setMobile(m1);
	
	EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
	EntityManager EM=EMF.createEntityManager();
	EntityTransaction ET=EM.getTransaction();
	ET.begin();
	EM.persist(person);
	EM.persist(s1);
	EM.persist(s2);
	EM.persist(m1);
	ET.commit();
	}
}
