package com.One_To_Many_Mapping.entity;

import javax.persistence.*;
@Entity
public class Sim {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String providername;
	private long simnumber;
	 int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getProvidername() {
		return providername;
	}
	public void setProvidername(String providername) {
		this.providername = providername;
	}
	public long getSimnumber() {
		return simnumber;
	}
	public void setSimnumber(long simnumber) {
		this.simnumber = simnumber;
	}

}
