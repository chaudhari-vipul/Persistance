package com.One_To_Many_Mapping.entity;

import java.util.List;

import javax.persistence.*;
@Entity
public class Mobile {
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String mobilename;
	private String brand;
	private double cost;
	
	@OneToMany
	private List<Sim> sims;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getMobilename() {
		return mobilename;
	}
	public void setMobilename(String mobilename) {
		this.mobilename = mobilename;
	}
	public String getBrand() {
		return brand;
	}
	public void setBrand(String brand) {
		this.brand = brand;
	}
	public List<Sim> getSims() {
		return sims;
	}
	public void setSims(List<Sim> sims) {
		this.sims = sims;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}
}
