package com.One_To_Many_Hibernate_Bidirectional.dto;

import java.util.*;
import javax.persistence.*;
@Entity
public class Mobile 
{
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		int id;
		String name;
		String brand;
		double cost;
		@OneToMany (cascade = CascadeType.ALL)
		List<Sim> sims;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getBrand() {
			return brand;
		}
		public void setBrand(String brand) {
			this.brand = brand;
		}
		public double getCost() {
			return cost;
		}
		public void setCost(double cost) {
			this.cost = cost;
		}
		public List<Sim> getSims() {
			return sims;
		}
		public void setSims(List<Sim> sims) {
			this.sims = sims;
		}
}
