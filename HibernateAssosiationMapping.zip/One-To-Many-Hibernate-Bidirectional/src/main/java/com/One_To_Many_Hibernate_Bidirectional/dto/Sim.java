package com.One_To_Many_Hibernate_Bidirectional.dto;

import javax.persistence.*;

@Entity
public class Sim 
{	
		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		int id;
		String provider;
		String imrcNumber;
		long simNumber;
		@OneToOne
		@JoinColumn
		Mobile mobile;
		
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getProvider() {
			return provider;
		}
		public void setProvider(String provider) {
			this.provider = provider;
		}
		public String getImrcNumber() {
			return imrcNumber;
		}
		public void setImrcNumber(String imrcNumber) {
			this.imrcNumber = imrcNumber;
		}
		public long getSimNumber() {
			return simNumber;
		}
		public void setSimNumber(long simNumber) {
			this.simNumber = simNumber;
		}
		public Mobile getMobile() {
			return mobile;
		}
		public void setMobile(Mobile mobile) {
			this.mobile = mobile;
		}
}
