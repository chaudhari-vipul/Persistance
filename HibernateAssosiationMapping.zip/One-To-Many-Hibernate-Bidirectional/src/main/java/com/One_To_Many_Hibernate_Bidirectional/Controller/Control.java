package com.One_To_Many_Hibernate_Bidirectional.Controller;

import java.util.*;
import javax.persistence.*;
import com.One_To_Many_Hibernate_Bidirectional.dto.*;

public class Control {

	public static void main(String[] args) 
	{
		List<Sim> list=new ArrayList<Sim>();
		
		Sim sim1=new Sim();
		sim1.setProvider("Airtel");
		sim1.setImrcNumber("Artel452363");
		sim1.setSimNumber(7789886733l);
		
		Sim sim2=new Sim();
		sim2.setProvider("Jio");
		sim2.setImrcNumber("Jio689998");
		sim2.setSimNumber(9858848847l);
		
		list.add(sim1);
		list.add(sim2);
		
		Mobile mobile=new Mobile();
		mobile.setName("I-Phone 14 Pro");
		mobile.setBrand("Apple");
		mobile.setCost(123600);
		mobile.setSims(list);
		
		//sim1.setMobile(mobile);
		//sim2.setMobile(mobile);
		
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("Vipul");
		EntityManager EM=EMF.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		EM.persist(mobile);
		ET.commit();
	}
}
