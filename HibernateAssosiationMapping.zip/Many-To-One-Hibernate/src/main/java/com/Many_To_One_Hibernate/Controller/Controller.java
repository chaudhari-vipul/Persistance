package com.Many_To_One_Hibernate.Controller;

import javax.persistence.*;
import com.Many_To_One_Hibernate.Entity.*;

public class Controller {

	public static void main(String[] args) 
	{
		Hotel hotel=new Hotel();
		hotel.setName("Shivaji");
		hotel.setAddress("Pune");
		hotel.setManagerName("Mr.Shivaji Patil");
		
		Branch branch1=new Branch();
		branch1.setAddress("jalgaon");
		branch1.setManagerName("Mr.sharukh");
		branch1.setPhoneNumber(65892979697l);
		branch1.setHotel(hotel);
		
		Branch branch2=new Branch();
		branch2.setAddress("Mumbai");
		branch2.setManagerName("Mr.Joshi");
		branch2.setPhoneNumber(88912704760626l);
		branch2.setHotel(hotel);
		
		Branch branch3=new Branch();
		branch3.setAddress("Solapur");
		branch3.setManagerName("Miss.Shreya");
		branch3.setPhoneNumber(8962389665938l);
		branch3.setHotel(hotel);
		
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
		EntityManager EM=EMF.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		EM.persist(branch1);
		EM.persist(branch2);
		EM.persist(branch3);
		ET.commit();
	}

}
