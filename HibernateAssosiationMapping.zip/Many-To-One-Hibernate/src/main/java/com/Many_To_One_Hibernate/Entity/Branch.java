package com.Many_To_One_Hibernate.Entity;

import javax.persistence.*;

@Entity
public class Branch 
{
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String address;
	private String ManagerName;
	private long PhoneNumber;
	@ManyToOne (cascade=CascadeType.ALL)
	private Hotel hotel;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getManagerName() {
		return ManagerName;
	}
	public void setManagerName(String managerName) {
		ManagerName = managerName;
	}
	public long getPhoneNumber() {
		return PhoneNumber;
	}
	public void setPhoneNumber(long phoneNumber) {
		PhoneNumber = phoneNumber;
	}
	public Hotel getHotel() {
		return hotel;
	}
	public void setHotel(Hotel hotel) {
		this.hotel = hotel;
	}
}
