package com.employeeTest_hibernate.controller;

import com.employeeTest_hibernate.dto.EmployeeTest;
import com.employee_hibernate.dto.Employee;

public class Controller {

	public static void main(String[] args) {
		EmployeeTest EmpTest=new EmployeeTest();
		
		Employee Emp=new Employee();
		Emp.setEmpId(5);
		Emp.setEmpName("Vicky");
		Emp.setEmpRole("Db Devoloper");   
		Emp.setSalary(25000);
		
		EmpTest.saveEmployee(Emp);   //for Use Inserting Data into Database
		
				
	/*	Employee employee=EmpTest.getEmployee(3);  // for use to selection perpose
		if(employee!=null) {
			System.out.println("Employee Name is    "+employee.getEmpName());
			System.out.println("Employee Role is    "+employee.getEmpRole());
			System.out.println("Employee Salary is    "+employee.getSalary());
		}
		else {
			System.out.println("There is no Employee");	
		}
		*/
	//	EmpTest.updateEmployee(1);				//for update operation persose
		
	//	EmpTest.deleteEmployee(4);				//for Delete operation persose
		
	}

}
