package com.employeeTest_hibernate.dto;


import java.util.Scanner;

import javax.persistence.*;

import com.employee_hibernate.dto.Employee;

public class EmployeeTest 
{
	public void saveEmployee(Employee employee)
	{
	EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
	EntityManager EM=EMF.createEntityManager();
	EntityTransaction ET=EM.getTransaction();
	ET.begin();
	EM.persist(employee);
	ET.commit();
	}
	public Employee getEmployee(int id) {
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
		EntityManager EM=EMF.createEntityManager();
		Employee emp=EM.find(Employee.class,id);
		
		return emp;
	}
	public void updateEmployee(int id) {
		Scanner sc=new Scanner(System.in);
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
		EntityManager EM=EMF.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		Employee Emp=EM.find(Employee.class,id);
		if(Emp!=null) {
			System.out.println("Enter th Employee Details");
			Emp.setEmpName(sc.nextLine());
			Emp.setEmpRole(sc.nextLine());
			Emp.setSalary(sc.nextDouble());
			EM.merge(Emp);
		}else {
			System.out.println("There is no Record Updated");
		}
		ET.commit();
	}
	
	
	public void deleteEmployee(int id) {
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
		EntityManager EM=EMF.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		Employee Emp=EM.find(Employee.class,id);
		if(Emp!=null)
		{
		EM.remove(Emp);
		}
		else 
		{
			System.out.println("There is no Employee to Deleted");
		}
		ET.commit();
	}

	
	
	
	
	
	
	
	
	
	
	
}