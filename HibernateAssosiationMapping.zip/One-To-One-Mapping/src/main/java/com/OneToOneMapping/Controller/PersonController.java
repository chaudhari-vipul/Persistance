package com.OneToOneMapping.Controller;
import javax.persistence.*;
import com.OneToOneMapping.entity.*;

public class PersonController {

	public static void main(String[] args)
	{
	Person person=new Person();
	person.setName("Vipul");
	person.setAddress("Bhusawal");
	
	Adhar aadhar=new Adhar();
	aadhar.setAadharNumber(11223344l);
	aadhar.setFatherName("Ganesh");
	person.setAadhar(aadhar);
	
	EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
	EntityManager EM=EMF.createEntityManager();
	EntityTransaction ET=EM.getTransaction();
	ET.begin();
	EM.persist(aadhar);
	EM.persist(person);
	ET.commit();
	}
}
