package com.One_To_One_Hibernate_Bidirectional.Controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.One_To_One_Hibernate_Bidirectional.Entity.*;

public class Control {

	public static void main(String[] args) 
	{
		PanCard pan=new PanCard();
		pan.setNumber("CCVPC7892Q");
		pan.setFatherName("Kumar");
		
		Person person=new Person();
		person.setName("Ajay");
		person.setAge(87);
		person.setAddress("Pune");
		person.setPan(pan);
		pan.setPerson(person);
			
			
			EntityManagerFactory EMF=Persistence.createEntityManagerFactory("Vipul");
			EntityManager EM=EMF.createEntityManager();
			EntityTransaction ET=EM.getTransaction();
			ET.begin();
			EM.persist(person);
			EM.persist(pan);
			ET.commit();
	}

}
