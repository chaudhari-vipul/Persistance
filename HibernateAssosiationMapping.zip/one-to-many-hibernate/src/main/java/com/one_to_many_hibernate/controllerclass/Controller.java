package com.one_to_many_hibernate.controllerclass;

import java.util.*;
import javax.persistence.*;
import com.one_to_many_hibernate.EntityClasses.*;

public class Controller {

	public static void main(String[] args) 
	{					
		UPI_account phonepay=new UPI_account();
		phonepay.setUPIId("Fai1873shikh");
		phonepay.setAccountNumber(71691926l);
		phonepay.setPassword("Faizal@123");
		
		UPI_account Gpay=new UPI_account();
		Gpay.setUPIId("Faizal8947");
		Gpay.setAccountNumber(71691926l);
		Gpay.setPassword("Faizal@456");
		
		UPI_account Paytm=new UPI_account();
		Paytm.setUPIId("Faizzu123");
		Paytm.setAccountNumber(71691926l);
		Paytm.setPassword("Faizal@789");
		
		UPI_account AmazonPay=new UPI_account();
		AmazonPay.setUPIId("Fai6923shikh");
		AmazonPay.setAccountNumber(71691926l);
		AmazonPay.setPassword("Faizal@786");
		
		List <UPI_account> Upiaccount1=new ArrayList <UPI_account>();
		Upiaccount1.add(phonepay);
		Upiaccount1.add(Gpay);
		Upiaccount1.add(Paytm);
		Upiaccount1.add(AmazonPay);
	
		Account account=new Account();	
		account.setAccountNumber(71691926661698l);
		account.setIDFCNumber("SBIN0000423");
		account.setAdharNumber(87359298972093709l);
		account.setUpiAccount1(Upiaccount1);
		
		List<Account> accounts=new ArrayList<Account>(); 
		accounts.add(account);
		
		Person person=new Person();
		person.setName("Shaikh Fazal");
		person.setAdharNumber(873592989l);
		person.setPanNumber("FAIZAL6749Q");
		person.setAccount(accounts);
		
		EntityManagerFactory EMF=Persistence.createEntityManagerFactory("simha");
		EntityManager EM=EMF.createEntityManager();
		EntityTransaction ET=EM.getTransaction();
		ET.begin();
		EM.persist(person);
		EM.persist(accounts);
		EM.persist(phonepay);
		EM.persist(Gpay);
		EM.persist(Paytm);
		EM.persist(AmazonPay);
		ET.commit();
	}
}
