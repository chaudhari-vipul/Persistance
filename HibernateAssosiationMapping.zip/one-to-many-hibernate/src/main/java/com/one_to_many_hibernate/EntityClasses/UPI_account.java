package com.one_to_many_hibernate.EntityClasses;

import javax.persistence.*;

@Entity
public class UPI_account 
{
		@Id
		@GeneratedValue(strategy =GenerationType.IDENTITY)
		private int id;
		private String UPIId;
		private long AccountNumber;
		private String Password;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getUPIId() {
			return UPIId;
		}
		public void setUPIId(String uPIId) {
			UPIId = uPIId;
		}
		public long getAccountNumber() {
			return AccountNumber;
		}
		public void setAccountNumber(long accountNumber) {
			AccountNumber = accountNumber;
		}
		public String getPassword() {
			return Password;
		}
		public void setPassword(String password) {
			Password = password;
		}
		
}
