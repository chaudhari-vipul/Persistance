package com.one_to_many_hibernate.EntityClasses;

import java.util.*;

import javax.persistence.*;

@Entity
public class Account 
{
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
		private int id;
		private long AccountNumber;
		private String IDFCNumber;
		private long AdharNumber;
		@OneToMany
		private List <UPI_account> UpiAccount1;
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public long getAccountNumber() {
			return AccountNumber;
		}
		public void setAccountNumber(long accountNumber) {
			AccountNumber = accountNumber;
		}
		public String getIDFCNumber() {
			return IDFCNumber;
		}
		public void setIDFCNumber(String iDFCNumber) {
			IDFCNumber = iDFCNumber;
		}
		public List<UPI_account> getUpiAccount1() {
			return UpiAccount1;
		}
		public void setUpiAccount1(List<UPI_account> upiAccount1) {
			UpiAccount1 = upiAccount1;
		}
		public long getAdharNumber() {
			return AdharNumber;
		}
		public void setAdharNumber(long adharNumber) {
			AdharNumber = adharNumber;
		}
		
}
