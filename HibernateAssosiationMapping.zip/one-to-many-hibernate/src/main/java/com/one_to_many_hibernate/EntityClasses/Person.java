package com.one_to_many_hibernate.EntityClasses;

import java.util.List;

import javax.persistence.*;

@Entity
public class Person 
{
	@Id
	@GeneratedValue(strategy =GenerationType.IDENTITY)
	private int id;
	private String Name;
	private long AdharNumber;
	private String PanNumber;
	@OneToMany
	private List <Account> account;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public long getAdharNumber() {
		return AdharNumber;
	}
	public void setAdharNumber(long adharNumber) {
		AdharNumber = adharNumber;
	}
	public String getPanNumber() {
		return PanNumber;
	}
	public void setPanNumber(String panNumber) {
		PanNumber = panNumber;
	}
	public List<Account> getAccount() {
		return account;
	}
	public void setAccount(List<Account> account) {
		this.account = account;
	}
	
}
